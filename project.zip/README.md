# Aero Store

## Shizuku access
Aero Store can use Shizuku (`moe.shizuku.privileged.api`) for silent install / uninstall, with no pairing code.

1. Install Shizuku and start it (Wireless debugging or root).
2. In Aero Store > menu > Install method, choose **Shizuku** and tap **Allow**.
3. Keep the Aero Store switch on in Shizuku > Authorized apps.

If Shizuku is not ready, Aero Store falls back to the normal Android installer.
Code: `AeroAccess.java` (state / permission / shell runner through Shizuku).

## Web page bridge
The store page talks to the app through `window.Bridge`. The install method value is now `"shizuku"`
(`getInstallMode()`, `setInstallMode("shizuku")`). The old value `"aerohub"` is still accepted and means Shizuku.
New names: `getShizukuState()` and `shizukuAction()` (the old `getAeroState()` / `aeroAction()` still work).
The app calls `window.shizuku()` (and the old `window.aeroHub()`) when the Shizuku state changes.
