package com.aero.store;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Base64;

import androidx.annotation.NonNull;

import java.io.ByteArrayInputStream;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.Random;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import sun.security.x509.AlgorithmId;
import sun.security.x509.CertificateAlgorithmId;
import sun.security.x509.CertificateExtensions;
import sun.security.x509.CertificateIssuerName;
import sun.security.x509.CertificateSerialNumber;
import sun.security.x509.CertificateSubjectName;
import sun.security.x509.CertificateValidity;
import sun.security.x509.CertificateVersion;
import sun.security.x509.CertificateX509Key;
import sun.security.x509.KeyIdentifier;
import sun.security.x509.PrivateKeyUsageExtension;
import sun.security.x509.SubjectKeyIdentifierExtension;
import sun.security.x509.X500Name;
import sun.security.x509.X509CertImpl;
import sun.security.x509.X509CertInfo;

/**
 * ADB-over-Wi-Fi ("Wireless debugging") connection used by the "Wireless" install method.
 * The key pair is created once and kept, so the phone only has to be paired one time.
 */
public class AdbManager extends AbsAdbConnectionManager {

    private static AdbManager INSTANCE;

    public static synchronized AdbManager get(Context ctx) throws Exception {
        if (INSTANCE == null) INSTANCE = new AdbManager(ctx.getApplicationContext());
        return INSTANCE;
    }

    private PrivateKey mPrivateKey;
    private Certificate mCertificate;

    private AdbManager(Context ctx) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        SharedPreferences sp = ctx.getSharedPreferences("adbkey", Context.MODE_PRIVATE);
        String k = sp.getString("k", null);
        String c = sp.getString("c", null);
        if (k != null && c != null) {
            try {
                mPrivateKey = KeyFactory.getInstance("RSA")
                        .generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(k, Base64.NO_WRAP)));
                mCertificate = CertificateFactory.getInstance("X.509")
                        .generateCertificate(new ByteArrayInputStream(Base64.decode(c, Base64.NO_WRAP)));
            } catch (Exception e) {
                mPrivateKey = null;
                mCertificate = null;
            }
        }
        if (mPrivateKey == null || mCertificate == null) {
            KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
            gen.initialize(2048, new SecureRandom());
            KeyPair pair = gen.generateKeyPair();
            PublicKey publicKey = pair.getPublic();
            mPrivateKey = pair.getPrivate();

            String algorithmName = "SHA512withRSA";
            Date notBefore = new Date();
            Date notAfter = new Date(System.currentTimeMillis() + 10L * 365 * 86400000L);
            CertificateExtensions ext = new CertificateExtensions();
            ext.set("SubjectKeyIdentifier", new SubjectKeyIdentifierExtension(
                    new KeyIdentifier(publicKey).getIdentifier()));
            X500Name name = new X500Name("CN=Aero Store");
            ext.set("PrivateKeyUsage", new PrivateKeyUsageExtension(notBefore, notAfter));
            X509CertInfo info = new X509CertInfo();
            info.set("version", new CertificateVersion(2));
            info.set("serialNumber", new CertificateSerialNumber(new Random().nextInt() & Integer.MAX_VALUE));
            info.set("algorithmID", new CertificateAlgorithmId(AlgorithmId.get(algorithmName)));
            info.set("subject", new CertificateSubjectName(name));
            info.set("key", new CertificateX509Key(publicKey));
            info.set("validity", new CertificateValidity(notBefore, notAfter));
            info.set("issuer", new CertificateIssuerName(name));
            info.set("extensions", ext);
            X509CertImpl cert = new X509CertImpl(info);
            cert.sign(mPrivateKey, algorithmName);
            mCertificate = cert;

            sp.edit()
                    .putString("k", Base64.encodeToString(mPrivateKey.getEncoded(), Base64.NO_WRAP))
                    .putString("c", Base64.encodeToString(mCertificate.getEncoded(), Base64.NO_WRAP))
                    .apply();
        }
    }

    @NonNull @Override protected PrivateKey getPrivateKey() { return mPrivateKey; }

    @NonNull @Override protected Certificate getCertificate() { return mCertificate; }

    @NonNull @Override protected String getDeviceName() { return "AeroStore"; }
}
