package com.aero.store;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

import rikka.shizuku.Shizuku;

/** Shizuku access: state, permission request, polling and a safe shell command runner. */
final class AeroAccess {
    enum State { NotInstalled, NotRunning, NoPermission, Blocked, Ready }

    static final String PKG = "moe.shizuku.privileged.api";
    private static final int REQ = 4127;
    private static volatile State state = State.NoPermission;
    /** Called on the main thread whenever the state changes. */
    static volatile Runnable onChange;

    private static Context app;
    private static volatile int pollGen = 0;
    private static boolean listening = false;
    private static final Handler main = new Handler(Looper.getMainLooper());

    private AeroAccess() { }

    /** Output of a shell command. */
    static final class Result {
        final int code;
        final String out;
        Result(int code, String out) { this.code = code; this.out = out; }
    }

    static State state() { return state; }

    static boolean ready() { return state == State.Ready; }

    /** Call once in Activity.onCreate (safe to call again). */
    static synchronized void init(Context context) {
        app = context.getApplicationContext();
        if (!listening) {
            listening = true;
            try {
                Shizuku.addBinderReceivedListener(AeroAccess::recheck);
                Shizuku.addBinderDeadListener(AeroAccess::recheck);
                Shizuku.addRequestPermissionResultListener((code, result) -> recheck());
            } catch (Throwable t) { listening = false; }
        }
    }

    static boolean installed(Context c) {
        try { c.getPackageManager().getPackageInfo(PKG, 0); return true; }
        catch (Throwable t) { return false; }
    }

    static String message(State s) {
        switch (s) {
            case NotInstalled: return "Shizuku is not installed. Get it from the store first.";
            case NotRunning:   return "Start Shizuku (Wireless debugging or root), then come back";
            case NoPermission: return "Tap Allow to give Aero Store Shizuku access";
            case Blocked:      return "Blocked: switch Aero Store on in Shizuku > Authorized apps";
            default:           return "Shizuku connected";
        }
    }

    private static void set(State s) {
        if (state != s) {
            state = s;
            main.post(() -> { Runnable r = onChange; if (r != null) r.run(); });
        }
    }

    private static void checkBlocking() {
        Context c = app;
        if (c == null) return;
        if (!installed(c)) { set(State.NotInstalled); return; }
        int code;
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) code = -1;
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) code = 1;
            else code = 0;
        } catch (Throwable t) { code = -1; }
        if (code < 0) set(State.NotRunning);
        else if (code == 0) {
            boolean denied = false;
            try { denied = Shizuku.shouldShowRequestPermissionRationale(); } catch (Throwable ignore) { }
            set(denied ? State.Blocked : State.NoPermission);
        } else set(State.Ready);
    }

    static void recheck() {
        Thread t = new Thread(() -> { try { checkBlocking(); } catch (Throwable ignore) { } });
        t.setDaemon(true);
        t.start();
    }

    /** Re-check every ~4 s while the app is on screen, in case Shizuku was stopped. */
    static void startPolling(Context context) {
        init(context);
        final int g = ++pollGen;
        recheck();
        Thread t = new Thread(() -> {
            while (pollGen == g) {
                try { Thread.sleep(4000); } catch (InterruptedException ignore) { }
                if (pollGen == g) { try { checkBlocking(); } catch (Throwable ignore) { } }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    static void stopPolling() { pollGen++; }

    /** Shows Shizuku's Allow/Deny popup. The answer arrives through the listener set in [init]. */
    static void requestPermission(Activity act) {
        try {
            Shizuku.requestPermission(REQ);
        } catch (Throwable e) {
            recheck();
        }
    }

    static void openShizuku(Context context) {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage(PKG);
            if (i != null) context.startActivity(i);
        } catch (Throwable ignore) { }
    }

    /** Safe shell quoting: 'text' with every ' replaced by '\'' . Always quote file / package names with it. */
    static String sq(String s) { return "'" + s.replace("'", "'\\''") + "'"; }

    /** Shizuku.newProcess is private in the current API, so it is called through reflection. */
    private static Process proc(String cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        return (Process) m.invoke(null, new String[]{"sh", "-c", cmd}, null, null);
    }

    private static Thread drain(final InputStream in, final ByteArrayOutputStream out) {
        Thread t = new Thread(() -> {
            try {
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) >= 0) {
                    synchronized (out) {
                        int room = 512 * 1024 - out.size();
                        if (room > 0) out.write(b, 0, Math.min(n, room));
                    }
                }
            } catch (Throwable ignore) { }
        });
        t.setDaemon(true);
        t.start();
        return t;
    }

    /** Runs a shell command as the shell user. Blocking: call from a background thread. */
    static Result run(String cmd) throws Exception {
        if (state != State.Ready) throw new IllegalStateException("Shizuku is not connected.");
        try {
            Process p = proc(cmd);
            try { p.getOutputStream().close(); } catch (Throwable ignore) { }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ByteArrayOutputStream err = new ByteArrayOutputStream();
            Thread t1 = drain(p.getInputStream(), out);
            Thread t2 = drain(p.getErrorStream(), err);
            t1.join(60_000);
            t2.join(1_000);
            int code;
            try { code = p.exitValue(); } catch (IllegalThreadStateException e) { p.destroy(); code = -1; }
            String text;
            synchronized (out) { text = new String(out.toByteArray(), StandardCharsets.UTF_8); }
            synchronized (err) { text += new String(err.toByteArray(), StandardCharsets.UTF_8); }
            return new Result(code, text);
        } catch (Exception e) {
            recheck();
            throw new IllegalStateException("Shizuku: " + (e.getMessage() != null ? e.getMessage() : "connection failed"));
        }
    }
}
