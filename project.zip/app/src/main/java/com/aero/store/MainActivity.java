package com.aero.store;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.provider.Settings;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.text.InputType;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONObject;

import io.github.muntashirakon.adb.AdbStream;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;
import java.util.List;

/**
 * Aero Store wrapper.
 *
 * All download / install UI (Get button, progress ring, Downloads page) now lives in the
 * web page so it follows the selected app theme (light / dark / green / glass).
 * This class only does the native work and exposes it to the page as "AeroBridge":
 *   start(url, fileName)  - download a direct link
 *   cancel(url)           - cancel or remove a download
 *   install(url)          - open the Android installer for a finished download
 *   mark(url)             - remember which app a MediaFire page link belongs to
 *   state()               - JSON of all downloads: {url:{status,pct,got,total}}
 * and pushes changes back with window.aeroOnState(json).
 */
public class MainActivity extends Activity {

    // The build reads your link from site.txt and puts it here.
    static final String SITE = "https://YOUR-SITE.pages.dev";

    /* Shown instead of the default Android error page when the site cannot load: the offline game (assets/aero-run.html). */
    static final String OFFLINE_URL = "file:///android_asset/aero-run.html";

    WebView web;
    String failedUrl = null;
    FrameLayout root;
    SharedPreferences prefs;
    Handler h = new Handler(Looper.getMainLooper());

    volatile String pendingKey = null; // app link the user tapped before a MediaFire page opened
    String lastJson = null;
    boolean polling = false;
    boolean active = false;
    int topInsetPx = 0;

    /* package added / removed / replaced -> page re-checks which apps are installed (Open / Uninstall buttons) */
    final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { h.postDelayed(() -> refreshWeb(), 400); }
    };

    final Runnable tick = new Runnable() {
        @Override public void run() {
            push(false);
            if (active) {
                h.postDelayed(this, 500);
            } else {
                polling = false;
            }
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Downloader.init(this);
        prefs = getSharedPreferences("dl", MODE_PRIVATE);
        try {
            IntentFilter pf = new IntentFilter();
            pf.addAction(Intent.ACTION_PACKAGE_ADDED);
            pf.addAction(Intent.ACTION_PACKAGE_REMOVED);
            pf.addAction(Intent.ACTION_PACKAGE_REPLACED);
            pf.addDataScheme("package");
            registerReceiver(pkgReceiver, pf);
        } catch (Throwable t) { }

        transparentBars();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            topInsetPx = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            // keep the page above the on-screen keyboard
            root.setPadding(0, 0, 0, insets.getInsets(WindowInsetsCompat.Type.ime()).bottom);
            applyInsets();
            return insets; // not consumed, WebView sits under the bar
        });
        setContentView(root);
        transparentBars(); // again after the content view exists

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "AeroBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                return true;
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    String eu = r.getUrl().toString();
                    if (eu.startsWith("file:")) return; // the game itself: never loop
                    failedUrl = eu;
                    v.loadUrl(OFFLINE_URL);
                }
            }
            @Override public void onPageFinished(WebView v, String url) {
                applyInsets();
                push(true);
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> startFromWeb(url, ua, cd, mime));
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        web.loadUrl(SITE);
        hideNav();
    }

    /* Fully transparent status/navigation bars (no grey scrim); page draws behind them, icons stay visible. */
    void transparentBars() {
        android.view.Window w = getWindow();
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        WindowCompat.setDecorFitsSystemWindows(w, false);
        // legacy flags: some OEM skins (MIUI etc.) only honour these for a truly transparent bar
        // applied on every SDK (not only < 30): MIUI / One UI still need it on Android 11+
        View dv = w.getDecorView();
        dv.setSystemUiVisibility(dv.getSystemUiVisibility()
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        // draw into the notch / cutout area so no black strip appears behind the status bar
        if (Build.VERSION.SDK_INT >= 28) {
            w.getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setStatusBarContrastEnforced(false);
            w.setNavigationBarContrastEnforced(false);
        }
    }

    /* Tell the page how tall the status bar is (CSS var --sat) and make the bar icons follow the page theme. */
    void applyInsets() {
        if (web == null) return;
        float d = getResources().getDisplayMetrics().density;
        String js = "(function(){try{"
            + "document.documentElement.style.setProperty('--sat','" + (topInsetPx / d) + "px');"
            + "if(window.__aeroBar)return;window.__aeroBar=1;"
            + "function f(){try{var t=document.createElement('div');"
            + "t.style.cssText='display:none;background:var(--bg,#fff)';document.documentElement.appendChild(t);"
            + "var c=getComputedStyle(t).backgroundColor.match(/[\\d.]+/g);t.remove();"
            + "var l=0.299*c[0]+0.587*c[1]+0.114*c[2];AeroBridge.bar(l<140);}catch(e){}}"
            + "f();new MutationObserver(f).observe(document.documentElement,{attributes:true});"
            + "var m=matchMedia('(prefers-color-scheme:dark)');"
            + "if(m.addEventListener)m.addEventListener('change',f);"
            + "}catch(e){}})()";
        web.evaluateJavascript(js, null);
    }

    /* Keep the status bar visible, hide the navigation bar (swipe from the edge shows it briefly). */
    void hideNav() {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (c == null) return;
        c.hide(WindowInsetsCompat.Type.navigationBars());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) { transparentBars(); hideNav(); }
    }

    @Override protected void onResume() {
        super.onResume();
        transparentBars();
        hideNav();
        push(true);
        ensurePolling();
        PairingService.listener = p -> h.post(() -> showCodeDialog(p));
        handlePairIntent();
        // back from the installer / uninstall: let the page re-check which apps are installed
        if (web != null) web.evaluateJavascript("window.aeroRefresh&&window.aeroRefresh()", null);
    }

    @Override protected void onPause() {
        PairingService.listener = null;
        super.onPause();
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handlePairIntent();
    }

    @Override public void onBackPressed() {
        String cu = web.getUrl();
        if (cu != null && cu.startsWith("file:///android_asset")) super.onBackPressed(); // leave from the game
        else if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        alive = false;
        h.removeCallbacks(tick);
        try { unregisterReceiver(pkgReceiver); } catch (Throwable t) { }
        super.onDestroy();
    }

    /* ---------- bridge exposed to the web page ---------- */

    class Bridge {
        @JavascriptInterface public void start(final String key, final String name) {
            h.post(() -> startDirect(key, name));
        }
        @JavascriptInterface public void cancel(final String key) {
            h.post(() -> removeKey(key));
        }
        @JavascriptInterface public void install(final String key) {
            h.post(() -> installKey(key));
        }
        @JavascriptInterface public void retry() {
            h.post(() -> web.loadUrl(failedUrl != null ? failedUrl : SITE));
        }
        @JavascriptInterface public void showKeyboard() {
            h.post(() -> {
                web.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT);
            });
        }
        @JavascriptInterface public void bar(final boolean darkPage) {
            h.post(() -> {
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
                if (c != null) c.setAppearanceLightStatusBars(!darkPage);
            });
        }
        /* the store page tells the app its theme; the offline game reads it back */
        @JavascriptInterface public void saveTheme(String t) {
            if (t != null && t.matches("dark|light|green|glass|auto")) prefs.edit().putString("theme", t).apply();
        }
        @JavascriptInterface public String getTheme() {
            return prefs.getString("theme", "auto");
        }
        @JavascriptInterface public void mark(String key) {
            pendingKey = key;
        }
        @JavascriptInterface public void pairWireless() {
            h.post(() -> showPairDialog());
        }
        @JavascriptInterface public boolean isPaired() {
            return prefs.getBoolean("wpaired", false);
        }
        @JavascriptInterface public String getInstallMode() {
            return installMode();
        }
        @JavascriptInterface public void setInstallMode(final String mode) {
            h.post(() -> chooseInstallMode(mode));
        }
        @JavascriptInterface public String state() {
            return buildState().toString();
        }
        /* pkgsJson: ["com.a","com.b"] -> JSON array of the ones installed on this phone */
        @JavascriptInterface public String installed(String pkgsJson) {
            return installedOf(pkgsJson);
        }
        @JavascriptInterface public void open(final String pkg) {
            h.post(() -> openPkg(pkg));
        }
        @JavascriptInterface public void uninstall(final String pkg) {
            h.post(() -> uninstallPkg(pkg));
        }
        /* extra options of the Wireless method: {"tcp":bool,"port":int,"legacy":bool} */
        @JavascriptInterface public String getWirelessOpts() {
            JSONObject o = new JSONObject();
            try {
                o.put("tcp", prefs.getBoolean("tcp", false));
                o.put("port", prefs.getInt("tcpport", 5555));
                o.put("legacy", prefs.getBoolean("legacy", false));
            } catch (Exception e) { }
            return o.toString();
        }
        @JavascriptInterface public void setTcpMode(final boolean on) {
            h.post(() -> {
                prefs.edit().putBoolean("tcp", on).apply();
                if (on) applyTcp();
            });
        }
        @JavascriptInterface public void setLegacyPairing(final boolean on) {
            prefs.edit().putBoolean("legacy", on).apply();
        }
        @JavascriptInterface public void editTcpPort() {
            h.post(() -> showPortDialog());
        }
    }

    /* ---------- Wireless options: TCP mode, TCP port, Legacy pairing ---------- */

    AlertDialog codeDlg;

    void optsRefresh() {
        if (web != null) web.evaluateJavascript("window.aeroOpts&&window.aeroOpts()", null);
    }

    void handlePairIntent() {
        Intent i = getIntent();
        if (i == null) return;
        int p = i.getIntExtra("pairPort", -1);
        if (p >= 0) {
            i.removeExtra("pairPort");
            showCodeDialog(p);
        }
    }

    FrameLayout padded(View v) {
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(v);
        return box;
    }

    void stopPairingService() {
        try { startService(new Intent(this, PairingService.class).setAction(PairingService.ACTION_STOP)); } catch (Throwable t) { }
    }

    /* Legacy pairing: the 6-digit code is typed in this dialog instead of a notification. */
    void showCodeDialog(final int port) {
        if (isFinishing()) return;
        if (codeDlg != null && codeDlg.isShowing()) return;
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("6-digit pairing code");
        et.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});
        codeDlg = new AlertDialog.Builder(this)
                .setTitle("Pairing code")
                .setMessage("Type the code shown in the Wireless debugging pairing pop-up.")
                .setView(padded(et))
                .setPositiveButton("Pair", (d, w) -> pairWithCode(port, et.getText().toString().trim()))
                .setNegativeButton("Cancel", (d, w) -> stopPairingService())
                .create();
        codeDlg.show();
    }

    void pairWithCode(final int port, final String code) {
        if (code.isEmpty()) { showCodeDialog(port); return; }
        Toast.makeText(this, "Pairing...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            boolean ok = false;
            String msg = "";
            try {
                ok = AdbManager.get(this).pair("127.0.0.1", port, code);
            } catch (Throwable t) {
                msg = String.valueOf(t.getMessage());
            }
            final boolean fok = ok;
            final String fmsg = msg;
            h.post(() -> {
                if (fok) {
                    prefs.edit().putBoolean("wpaired", true).apply();
                    stopPairingService();
                    Toast.makeText(this, "Paired successfully", Toast.LENGTH_LONG).show();
                    optsRefresh();
                    if (prefs.getBoolean("tcp", false)) applyTcp();
                } else {
                    Toast.makeText(this, "Pairing failed" + (fmsg.isEmpty() ? "" : " (" + fmsg + ")")
                            + ". Check the code and try again.", Toast.LENGTH_LONG).show();
                    showCodeDialog(port);
                }
            });
        }).start();
    }

    void showPortDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setText(String.valueOf(prefs.getInt("tcpport", 5555)));
        et.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle("TCP port")
                .setView(padded(et))
                .setPositiveButton("Save", (d, w) -> {
                    int v = -1;
                    try { v = Integer.parseInt(et.getText().toString().trim()); } catch (Exception e) { }
                    if (v < 1024 || v > 65535) {
                        Toast.makeText(this, "Enter a port between 1024 and 65535", Toast.LENGTH_LONG).show();
                        return;
                    }
                    prefs.edit().putInt("tcpport", v).apply();
                    optsRefresh();
                    if (prefs.getBoolean("tcp", false)) applyTcp();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /* Connect to adbd: through TCP on this phone first (works without Wi-Fi), otherwise through Wireless debugging. */
    boolean connectAdb(AdbManager m) throws Exception {
        if (prefs.getBoolean("tcp", false)) {
            try {
                if (m.connect("127.0.0.1", prefs.getInt("tcpport", 5555))) return true;
            } catch (Throwable t) { }
        }
        return m.autoConnect(this, 10000);
    }

    /* TCP mode: ask adbd (over Wireless debugging) to also listen on the chosen TCP port, so later installs need no Wi-Fi. */
    void applyTcp() {
        if (!prefs.getBoolean("tcp", false)) return;
        if (!prefs.getBoolean("wpaired", false)) {
            Toast.makeText(this, "Pair Wireless debugging first, then TCP mode will switch on", Toast.LENGTH_LONG).show();
            return;
        }
        final int port = prefs.getInt("tcpport", 5555);
        Toast.makeText(this, "Switching on TCP mode...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            boolean ok = false;
            String msg = "";
            AdbStream st = null;
            AdbManager m = null;
            try {
                m = AdbManager.get(this);
                if (!m.isConnected() && !m.autoConnect(this, 10000)) {
                    throw new Exception("Turn on Wireless debugging and connect to Wi-Fi first.");
                }
                st = m.openStream("tcpip:" + port);
                ok = true;
                try { msg = readAll(st.openInputStream()).trim(); } catch (Throwable ignore) { } // adbd restarts, the stream may just end
            } catch (Throwable t) {
                msg = String.valueOf(t.getMessage());
            } finally {
                try { if (st != null) st.close(); } catch (Throwable t) { }
            }
            // adbd restarted, so the old connection is gone: the next install connects again on the TCP port
            try { if (m != null) m.disconnect(); } catch (Throwable t) { }
            final boolean fok = ok;
            final String fmsg = msg;
            h.post(() -> Toast.makeText(this, fok ? "TCP mode on, port " + port
                    : "TCP mode failed" + (fmsg.isEmpty() ? "" : ": " + fmsg), Toast.LENGTH_LONG).show());
        }).start();
    }

    /* ---------- installed apps / open ---------- */

    String installedOf(String pkgsJson) {
        org.json.JSONArray out = new org.json.JSONArray();
        try {
            org.json.JSONArray in = new org.json.JSONArray(pkgsJson);
            PackageManager pm = getPackageManager();
            for (int i = 0; i < in.length(); i++) {
                String p = in.optString(i, "");
                if (p.isEmpty()) continue;
                try { pm.getPackageInfo(p, 0); out.put(p); } catch (PackageManager.NameNotFoundException e) { }
            }
        } catch (Exception e) { }
        return out.toString();
    }

    void openPkg(String pkg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) { Toast.makeText(this, "Can't open this app", Toast.LENGTH_LONG).show(); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Can't open this app", Toast.LENGTH_LONG).show();
        }
    }

    /* Uninstall: Android shows its own confirm dialog; when it closes the page refreshes (onResume + package receiver). */
    void uninstallPkg(String pkg) {
        try {
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Can't uninstall this app", Toast.LENGTH_LONG).show();
        }
    }

    void refreshWeb() {
        if (web != null) web.evaluateJavascript("window.aeroRefresh&&window.aeroRefresh()", null);
    }

    /* ---------- downloads: done inside the app by Downloader (not the phone's Download Manager) ---------- */

    File dir() {
        return getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
    }

    void startDirect(String key, String name) {
        startDl(key, key, name, null, null);
    }

    // MediaFire (and any other page) hands the file to the WebView's download listener.
    void startFromWeb(String url, String ua, String cd, String mime) {
        String name = URLUtil.guessFileName(url, cd, mime);
        String key = pendingKey != null ? pendingKey : url;
        pendingKey = null;
        startDl(key, url, name, ua, CookieManager.getInstance().getCookie(url));
        String cur = web.getUrl();
        if (cur != null && cur.contains("mediafire.com") && web.canGoBack()) web.goBack();
    }

    void startDl(String key, String url, String name, String ua, String cookie) {
        try {
            Downloader.start(this, key, url, name, ua, cookie);
        } catch (Exception e) {
            Toast.makeText(this, "Download failed to start", Toast.LENGTH_LONG).show();
            return;
        }
        autoQueueAdd(key); // install by itself when this download finishes (Wireless mode)
        warmAdb();
        push(true);
        ensurePolling();
    }

    void removeKey(String key) {
        Downloader.remove(key);
        autoQueueRemove(key);
        push(true);
    }

    /* ---------- state -> web page ---------- */

    JSONObject buildState() {
        JSONObject out = Downloader.state();
        List<String> keys = new ArrayList<>();
        Iterator<String> it = out.keys();
        while (it.hasNext()) keys.add(it.next());
        boolean act = false;
        for (String k : keys) {
            String st = out.optJSONObject(k).optString("status");
            if ("running".equals(st) || "paused".equals(st)) act = true;
            else if ("done".equals(st)) maybeAutoInstall(k, Downloader.localUri(k));
            else if ("failed".equals(st)) autoQueueRemove(k);
        }
        active = act;
        return out;
    }

    void push(boolean force) {
        if (web == null) return;
        String json = buildState().toString();
        if (!force && json.equals(lastJson)) return;
        lastJson = json;
        web.evaluateJavascript("window.aeroOnState&&window.aeroOnState(" + json + ")", null);
    }

    void ensurePolling() {
        if (polling) return;
        polling = true;
        h.removeCallbacks(tick);
        h.postDelayed(tick, 500);
    }

    /* ---------- auto install (Wireless debugging) ---------- */

    /* downloads started in this app that should install by themselves once finished */
    synchronized void autoQueueAdd(String key) {
        Set<String> s = new HashSet<>(prefs.getStringSet("autoq", new HashSet<String>()));
        s.add(key);
        prefs.edit().putStringSet("autoq", s).apply();
    }

    synchronized boolean autoQueueRemove(String key) {
        Set<String> s = new HashSet<>(prefs.getStringSet("autoq", new HashSet<String>()));
        boolean had = s.remove(key);
        if (had) prefs.edit().putStringSet("autoq", s).apply();
        return had;
    }

    synchronized boolean autoQueueHas(String key) {
        return prefs.getStringSet("autoq", new HashSet<String>()).contains(key);
    }

    /* true when the chosen method (Wireless debugging) can install without the installer screen right now */
    boolean silentReady() {
        String mode = installMode();
        if ("wireless".equals(mode)) return Build.VERSION.SDK_INT >= 30 && prefs.getBoolean("wpaired", false);
        return false;
    }

    /* Called when a download is finished. Installs it at once (no extra tap) if Wireless debugging is ready;
       otherwise the page keeps showing the Install button as before. Runs only once per download. */
    void maybeAutoInstall(String key, final String local) {
        if (local == null || !autoQueueHas(key)) return;
        boolean silent = silentReady();
        if (!autoQueueRemove(key)) return; // already handled by another call
        if (!silent) return;
        h.post(() -> install(local));
    }

    /* ---------- install ---------- */

    void installKey(String key) {
        install(Downloader.localUri(key));
    }

    /* ---------- install method chosen in the menu: "normal" or "wireless" ---------- */

    String installMode() {
        String m = prefs.getString("mode", "normal");
        return "wireless".equals(m) ? m : "normal";
    }

    void chooseInstallMode(String mode) {
        if ("wireless".equals(mode)) {
            if (Build.VERSION.SDK_INT < 30) {
                Toast.makeText(this, "Wireless debugging needs Android 11 or newer", Toast.LENGTH_LONG).show();
                prefs.edit().putString("mode", "normal").apply();
                return;
            }
            prefs.edit().putString("mode", "wireless").apply();
            if (!prefs.getBoolean("wpaired", false)) showPairDialog();
            else Toast.makeText(this, "Wireless debugging mode on", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.edit().putString("mode", "normal").apply();
    }

    /* Pick the installer: Wireless debugging (silent) when chosen, otherwise the normal Android installer. */
    void install(String localUri) {
        if (localUri == null) return;
        if ("wireless".equals(installMode())) { wirelessInstall(localUri); return; }
        normalInstall(localUri);
    }

    static String readAll(InputStream in) throws java.io.IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        return bo.toString("UTF-8");
    }

    /* ---------- Wireless debugging (own ADB connection) ---------- */

    /* One-time pairing: a notification takes the pairing code, so the Settings pop-up can stay open. */
    static final int REQ_NOTIF = 4712;

    void showPairDialog() { startPairing(); }

    void startPairing() {
        if (Build.VERSION.SDK_INT < 30) {
            Toast.makeText(this, "Wireless debugging needs Android 11 or newer", Toast.LENGTH_LONG).show();
            return;
        }
        final boolean legacy = prefs.getBoolean("legacy", false);
        if (!legacy && Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        try {
            startForegroundService(new Intent(this, PairingService.class).setAction(PairingService.ACTION_START));
        } catch (Throwable t) {
            Toast.makeText(this, "Could not start pairing: " + t.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        if (legacy) {
            // stay in the app: the code dialog appears here (use split-screen / a pop-up window for Settings)
            Toast.makeText(this, "Open Wireless debugging in split-screen or a pop-up window and tap \"Pair device with pairing code\". The code dialog will appear here.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Turn on Wireless debugging, tap \"Pair device with pairing code\", then type the code in the notification",
                Toast.LENGTH_LONG).show();
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); } catch (Throwable t) { }
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_NOTIF) return;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) startPairing();
        else Toast.makeText(this, "Allow notifications so you can type the pairing code", Toast.LENGTH_LONG).show();
    }

    /* Install over Wireless debugging: connect to adbd on this phone and stream the APK into "cmd package install". */
    /* ---------- one shared ADB connection ----------
       Every new connection makes Android show "Wireless debugging connected". So the store keeps ONE connection,
       installs go through it one after another, and it is kept alive (and opened already when a download starts)
       for as long as the store is being used. */

    final Object adbLock = new Object();
    volatile long adbLastUse = 0;
    volatile boolean keepAlive = false;
    volatile boolean alive = true;

    /* call with adbLock held */
    boolean ensureAdb(AdbManager m) throws Exception {
        if (!m.isConnected() && !connectAdb(m)) return false;
        adbLastUse = System.currentTimeMillis();
        startKeepAlive();
        return true;
    }

    /* tiny command every 15 s so the connection is not dropped while idle; stops 10 minutes after the last real use */
    void startKeepAlive() {
        if (keepAlive) return;
        keepAlive = true;
        new Thread(() -> {
            try {
                while (alive) {
                    Thread.sleep(15000);
                    if (System.currentTimeMillis() - adbLastUse > 10 * 60 * 1000L) break;
                    synchronized (adbLock) {
                        AdbStream s = null;
                        try {
                            AdbManager m = AdbManager.get(this);
                            if (!m.isConnected()) break;
                            s = m.openStream("shell:echo");
                            readAll(s.openInputStream());
                        } catch (Throwable t) {
                            break;
                        } finally {
                            try { if (s != null) s.close(); } catch (Throwable t) { }
                        }
                    }
                }
            } catch (InterruptedException e) { }
            keepAlive = false;
        }).start();
    }

    /* open the connection when a download starts, so it is ready (and announced only once) by the time the APK is done */
    void warmAdb() {
        if (!"wireless".equals(installMode()) || !silentReady()) return;
        new Thread(() -> {
            synchronized (adbLock) {
                try { ensureAdb(AdbManager.get(this)); } catch (Throwable t) { }
            }
        }).start();
    }

    void wirelessInstall(final String localUri) {
        if (!prefs.getBoolean("wpaired", false)) {
            Toast.makeText(this, "Pair Wireless debugging first", Toast.LENGTH_LONG).show();
            showPairDialog();
            return;
        }
        Toast.makeText(this, "Installing with Wireless debugging...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            boolean ok = false;
            String msg = "";
            synchronized (adbLock) { // installs run one after another over the same connection
                for (int attempt = 0; attempt < 2 && !ok; attempt++) {
                    AdbStream st = null;
                    boolean reused = false;
                    try {
                        File f = new File(Uri.parse(localUri).getPath());
                        AdbManager m = AdbManager.get(this);
                        reused = m.isConnected();
                        if (!ensureAdb(m)) {
                            throw new Exception("Could not connect. Turn on Wireless debugging and connect to Wi-Fi.");
                        }
                        st = m.openStream("exec:cmd package install -r -S " + f.length());
                        try (InputStream in = new FileInputStream(f)) {
                            OutputStream os = st.openOutputStream();
                            byte[] buf = new byte[64 * 1024];
                            int n;
                            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                            os.flush();
                        }
                        String out = readAll(st.openInputStream());
                        ok = out.contains("Success");
                        msg = out.trim();
                        if (!ok) break; // the install itself said no: a new connection would not help
                    } catch (Throwable t) {
                        msg = String.valueOf(t.getMessage());
                        // an old connection may have died: drop it and connect again once
                        if (reused) { try { AdbManager.get(this).disconnect(); } catch (Throwable x) { } }
                        else break;
                    } finally {
                        try { if (st != null) st.close(); } catch (Throwable t) { }
                    }
                }
                adbLastUse = System.currentTimeMillis();
            }
            final boolean fok = ok;
            final String fmsg = msg;
            h.post(() -> {
                if (fok) {
                    Toast.makeText(this, "Installed with Wireless debugging", Toast.LENGTH_LONG).show();
                    refreshWeb();
                } else {
                    Toast.makeText(this, "Wireless install failed" + (fmsg.isEmpty() ? "" : ": " + fmsg)
                            + ". Using the normal installer.", Toast.LENGTH_LONG).show();
                    normalInstall(localUri);
                }
            });
        }).start();
    }

    void normalInstall(String localUri) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow installs from this app, then tap Install again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        try {
            File f = new File(Uri.parse(localUri).getPath());
            Uri u = FileProvider.getUriForFile(this, getPackageName() + ".fp", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open installer", Toast.LENGTH_LONG).show();
        }
    }
}
