package com.aero.store;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    // The build reads your link from site.txt and puts it here.
    static final String SITE = "https://YOUR-SITE.pages.dev";

    static class Row {
        long id;
        String name, status, local;
        int pct;
        boolean done, running;
    }

    WebView web;
    FrameLayout root;
    LinearLayout panel, listBox;
    DownloadManager dm;
    SharedPreferences prefs;
    Handler h = new Handler(Looper.getMainLooper());
    boolean panelOpen = false;
    String lastSig = null;

    Runnable tick = new Runnable() {
        @Override public void run() {
            if (!panelOpen) return;
            refresh(false);
            h.postDelayed(this, 800);
        }
    };

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(0xFF0F1222);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        prefs = getSharedPreferences("dl", MODE_PRIVATE);

        root = new FrameLayout(this);
        root.setFitsSystemWindows(true);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                return true;
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime));
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        web.loadUrl(SITE);

        Button fab = new Button(this);
        fab.setText("↓ Downloads");
        fab.setAllCaps(false);
        fab.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF4B3DF2);
        g.setCornerRadius(dp(24));
        fab.setBackground(g);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, dp(44), Gravity.END | Gravity.BOTTOM);
        lp.setMargins(0, 0, dp(12), dp(96));
        root.addView(fab, lp);
        fab.setOnClickListener(v -> showPanel());

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFFF3F4F8);
        panel.setVisibility(View.GONE);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(8), dp(8));
        Button back = new Button(this);
        back.setText("←");
        back.setOnClickListener(v -> hidePanel());
        bar.addView(back);
        TextView title = text("Downloads", 20, true);
        title.setPadding(dp(12), 0, 0, 0);
        bar.addView(title);

        ScrollView sv = new ScrollView(this);
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        listBox.setPadding(dp(12), dp(4), dp(12), dp(12));
        sv.addView(listBox);

        panel.addView(bar);
        panel.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        root.addView(panel, new FrameLayout.LayoutParams(-1, -1));
    }

    void showPanel() {
        panelOpen = true;
        lastSig = null;
        panel.setVisibility(View.VISIBLE);
        h.removeCallbacks(tick);
        h.post(tick);
    }

    void hidePanel() {
        panelOpen = false;
        panel.setVisibility(View.GONE);
    }

    @Override public void onBackPressed() {
        if (panelOpen) hidePanel();
        else if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        h.removeCallbacks(tick);
        super.onDestroy();
    }

    List<Long> ids() {
        List<Long> l = new ArrayList<>();
        String s = prefs.getString("ids", "");
        for (String p : s.split(",")) {
            if (!p.isEmpty()) l.add(Long.parseLong(p));
        }
        return l;
    }

    void saveIds(List<Long> l) {
        StringBuilder sb = new StringBuilder();
        for (Long x : l) {
            if (sb.length() > 0) sb.append(',');
            sb.append(x);
        }
        prefs.edit().putString("ids", sb.toString()).apply();
    }

    void startDownload(String url, String ua, String cd, String mime) {
        String name = URLUtil.guessFileName(url, cd, mime);
        try {
            File old = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name);
            if (old.exists()) old.delete();

            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.addRequestHeader("User-Agent", ua);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) r.addRequestHeader("Cookie", ck);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name);
            long id = dm.enqueue(r);

            List<Long> l = ids();
            l.add(id);
            saveIds(l);
            showPanel();
        } catch (Exception e) {
            Toast.makeText(this, "Download failed to start", Toast.LENGTH_LONG).show();
        }
        String cur = web.getUrl();
        if (cur != null && cur.contains("mediafire.com") && web.canGoBack()) web.goBack();
    }

    Row query(long id) {
        Cursor c = dm.query(new DownloadManager.Query().setFilterById(id));
        if (c == null) return null;
        try {
            if (!c.moveToFirst()) return null;
            Row r = new Row();
            r.id = id;
            r.name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
            int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            long got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long tot = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            r.local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
            if (tot > 0) r.pct = (int) (got * 100 / tot);
            if (st == DownloadManager.STATUS_SUCCESSFUL) {
                r.done = true;
                r.status = "Ready to install";
            } else if (st == DownloadManager.STATUS_FAILED) {
                r.status = "Failed";
            } else if (st == DownloadManager.STATUS_PAUSED) {
                r.running = true;
                r.status = "Waiting for network...";
            } else {
                r.running = true;
                r.status = "Downloading " + r.pct + "%";
            }
            return r;
        } finally {
            c.close();
        }
    }

    void refresh(boolean force) {
        List<Long> l = ids();
        List<Row> rows = new ArrayList<>();
        List<Long> gone = new ArrayList<>();
        StringBuilder sig = new StringBuilder();
        for (int i = l.size() - 1; i >= 0; i--) {
            long id = l.get(i);
            Row r = query(id);
            if (r == null) { gone.add(id); continue; }
            rows.add(r);
            sig.append(r.id).append(r.status).append(r.pct).append(';');
        }
        if (!gone.isEmpty()) {
            l.removeAll(gone);
            saveIds(l);
        }
        String s = sig.toString();
        if (!force && s.equals(lastSig)) return;
        lastSig = s;

        listBox.removeAllViews();
        if (rows.isEmpty()) {
            TextView e = text("No downloads yet", 15, false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(40), 0, 0);
            listBox.addView(e, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        for (Row r : rows) {
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
            cl.setMargins(0, dp(8), 0, 0);
            listBox.addView(card(r), cl);
        }
    }

    LinearLayout card(final Row r) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(16));
        card.setBackground(bg);

        card.addView(text(r.name, 16, true));
        card.addView(text(r.status, 13, false));

        if (r.running) {
            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(100);
            pb.setProgress(r.pct);
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-1, dp(10));
            pl.setMargins(0, dp(8), 0, dp(4));
            card.addView(pb, pl);
        }

        LinearLayout btns = new LinearLayout(this);
        btns.setGravity(Gravity.END);
        if (r.done) {
            Button ins = new Button(this);
            ins.setText("Install");
            ins.setOnClickListener(v -> install(r.local));
            btns.addView(ins);
        }
        Button del = new Button(this);
        del.setText("Delete");
        del.setOnClickListener(v -> {
            dm.remove(r.id);
            List<Long> x = ids();
            x.remove(Long.valueOf(r.id));
            saveIds(x);
            refresh(true);
        });
        btns.addView(del);
        card.addView(btns);
        return card;
    }

    void install(String localUri) {
        if (localUri == null) return;
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow installs from this app, then tap Install again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        try {
            File f = new File(Uri.parse(localUri).getPath());
            Uri u = FileProvider.getUriForFile(this, getPackageName() + ".fp", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open installer", Toast.LENGTH_LONG).show();
        }
    }
}
