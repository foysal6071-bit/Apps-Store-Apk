package com.aero.store;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.NotificationCompat;
import androidx.core.app.RemoteInput;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

/**
 * Pairing helper for Wireless debugging. It finds the "Pair device with pairing code" service
 * on this phone and shows a notification where the person can type the 6-digit code, so the
 * Settings pop-up can stay open while typing.
 */
public class PairingService extends Service {

    static final String ACTION_START = "com.aero.store.PAIR_START";
    static final String ACTION_STOP = "com.aero.store.PAIR_STOP";
    static final String ACTION_REPLY = "com.aero.store.PAIR_REPLY";
    static final String KEY_CODE = "code";
    static final String CHANNEL = "pairing";
    static final int NID = 7001;

    final Handler h = new Handler(Looper.getMainLooper());
    NsdManager nsd;
    NsdManager.DiscoveryListener disc;
    boolean discovering = false;
    int port = -1;

    final Runnable timeout = () -> {
        notifyPlain("Pairing timed out", "Tap Pair Wireless debugging in the Aero Store menu to try again.", false);
        stopAll(false);
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        String a = i == null ? null : i.getAction();
        ensureChannel();
        if (ACTION_STOP.equals(a)) {
            stopAll(true);
            return START_NOT_STICKY;
        }
        if (ACTION_REPLY.equals(a)) {
            handleReply(i);
            return START_NOT_STICKY;
        }
        startFg(searching());
        h.removeCallbacks(timeout);
        h.postDelayed(timeout, 5 * 60 * 1000L);
        startDiscovery();
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        h.removeCallbacks(timeout);
        stopDiscovery();
        super.onDestroy();
    }

    /* ---------- notifications ---------- */

    void ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Wireless debugging pairing",
                    NotificationManager.IMPORTANCE_HIGH);
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    void startFg(Notification n) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NID, n);
    }

    void post(Notification n) {
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(NID, n);
    }

    NotificationCompat.Builder base(String title, String text) {
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setOnlyAlertOnce(true);
    }

    PendingIntent stopIntent() {
        Intent s = new Intent(this, PairingService.class).setAction(ACTION_STOP);
        return PendingIntent.getService(this, 1, s, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    Notification searching() {
        return base("Looking for the pairing pop-up",
                "In Settings > Developer options > Wireless debugging, tap \"Pair device with pairing code\" and keep it open.")
                .setOngoing(true)
                .addAction(0, "Cancel", stopIntent())
                .build();
    }

    Notification found(String note) {
        Intent ri = new Intent(this, PairingService.class).setAction(ACTION_REPLY).putExtra("port", port);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent pi = PendingIntent.getService(this, 0, ri, fl);
        RemoteInput rin = new RemoteInput.Builder(KEY_CODE).setLabel("Pairing code").build();
        NotificationCompat.Action act = new NotificationCompat.Action.Builder(
                android.R.drawable.ic_menu_edit, "Enter pairing code", pi).addRemoteInput(rin).build();
        return base("Pairing pop-up found", note)
                .setOngoing(true)
                .addAction(act)
                .addAction(0, "Cancel", stopIntent())
                .build();
    }

    void notifyPlain(String title, String text, boolean ongoing) {
        post(base(title, text).setOngoing(ongoing).setAutoCancel(!ongoing).build());
    }

    /* ---------- finding the pairing port ---------- */

    void startDiscovery() {
        if (discovering) return;
        nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);
        disc = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String t) { }
            @Override public void onDiscoveryStopped(String t) { }
            @Override public void onServiceFound(NsdServiceInfo s) { resolve(s); }
            @Override public void onServiceLost(NsdServiceInfo s) { }
            @Override public void onStartDiscoveryFailed(String t, int e) {
                discovering = false;
                h.post(() -> {
                    notifyPlain("Could not look for pairing", "Check that Wi-Fi is on and Wireless debugging is enabled.", false);
                    stopAll(false);
                });
            }
            @Override public void onStopDiscoveryFailed(String t, int e) { }
        };
        try {
            nsd.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, disc);
            discovering = true;
        } catch (Throwable t) {
            notifyPlain("Could not look for pairing", String.valueOf(t.getMessage()), false);
            stopAll(false);
        }
    }

    void stopDiscovery() {
        if (!discovering || nsd == null || disc == null) return;
        discovering = false;
        try { nsd.stopServiceDiscovery(disc); } catch (Throwable t) { }
    }

    @SuppressWarnings("deprecation")
    void resolve(NsdServiceInfo s) {
        try {
            nsd.resolveService(s, new NsdManager.ResolveListener() {
                @Override public void onResolveFailed(NsdServiceInfo i, int e) { }
                @Override public void onServiceResolved(NsdServiceInfo i) {
                    if (!isThisPhone(i.getHost())) return;
                    final int p = i.getPort();
                    h.post(() -> {
                        port = p;
                        post(found("Pull down this notification, tap \"Enter pairing code\" and type the 6-digit code from the pop-up."));
                    });
                }
            });
        } catch (Throwable t) {
            // another resolve is running; the next found event will try again
        }
    }

    /* the pairing pop-up of another phone on the same Wi-Fi must be ignored */
    static boolean isThisPhone(InetAddress host) {
        if (host == null || host.isLoopbackAddress()) return true;
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                Enumeration<InetAddress> ad = en.nextElement().getInetAddresses();
                while (ad.hasMoreElements()) {
                    if (ad.nextElement().equals(host)) return true;
                }
            }
        } catch (Throwable t) {
            return true;
        }
        return false;
    }

    /* ---------- code typed in the notification ---------- */

    void handleReply(Intent i) {
        final int p = i.getIntExtra("port", port);
        Bundle r = RemoteInput.getResultsFromIntent(i);
        CharSequence cs = r == null ? null : r.getCharSequence(KEY_CODE);
        if (p < 0 || cs == null || cs.toString().trim().isEmpty()) {
            notifyPlain("No code received", "Open the pairing pop-up again and retry.", false);
            return;
        }
        final String code = cs.toString().trim();
        port = p;
        post(base("Pairing...", "Please wait").setOngoing(true).build());
        new Thread(() -> {
            boolean ok = false;
            String msg = "";
            try {
                ok = AdbManager.get(this).pair("127.0.0.1", p, code);
            } catch (Throwable t) {
                msg = String.valueOf(t.getMessage());
            }
            final boolean fok = ok;
            final String fmsg = msg;
            h.post(() -> {
                if (fok) {
                    getSharedPreferences("dl", Context.MODE_PRIVATE).edit().putBoolean("wpaired", true).apply();
                    stopDiscovery();
                    h.removeCallbacks(timeout);
                    stopForeground(Service.STOP_FOREGROUND_DETACH);
                    notifyPlain("Paired successfully", "You can now install apps with Wireless debugging.", false);
                    stopSelf();
                } else {
                    post(found("Pairing failed" + (fmsg.isEmpty() ? "" : " (" + fmsg + ")")
                            + ". Check the code in the pop-up and try again."));
                }
            });
        }).start();
    }

    void stopAll(boolean removeNotification) {
        stopDiscovery();
        h.removeCallbacks(timeout);
        stopForeground(removeNotification ? Service.STOP_FOREGROUND_REMOVE : Service.STOP_FOREGROUND_DETACH);
        stopSelf();
    }
}
