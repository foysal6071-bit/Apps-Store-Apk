# Aero Store

## AeroHUB access
Aero Store can use AeroHUB (`com.example.mykuzu`) for silent install / uninstall, with no pairing code.

1. Install AeroHUB (it is in the store) and start its server.
2. In Aero Store > menu > Install method, choose **AeroHUB** and tap **Allow in AeroHUB**.
3. Keep the Aero Store switch on in AeroHUB > Apps.

If AeroHUB is not ready, Aero Store falls back to the normal Android installer.
Code: `AeroHub.java` (client), `AeroAccess.java` (state / permission / runner), `SecureStore.java` (encrypted token).
