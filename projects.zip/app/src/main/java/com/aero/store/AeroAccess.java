package com.aero.store;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

/** AeroHUB access: state, permission request, polling and a safe shell command runner. */
final class AeroAccess {
    enum State { NotInstalled, NotRunning, NoPermission, Blocked, Outdated, Ready }

    private static final int REQ = 4127;
    private static volatile State state = State.NoPermission;
    /** Called on the main thread whenever the state changes. */
    static volatile Runnable onChange;

    private static volatile String token = "";
    private static Context app;
    private static volatile int pollGen = 0;
    private static final Handler main = new Handler(Looper.getMainLooper());

    private AeroAccess() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("aerohub", Context.MODE_PRIVATE);
    }

    static State state() { return state; }

    static boolean ready() { return state == State.Ready; }

    /** Call once in Activity.onCreate. */
    static void init(Context context) {
        app = context.getApplicationContext();
        token = SecureStore.get(prefs(context), "token");
    }

    static boolean installed(Context c) {
        try { c.getPackageManager().getPackageInfo(AeroHub.PKG, 0); return true; }
        catch (Throwable t) { return false; }
    }

    static String message(State s) {
        switch (s) {
            case NotInstalled: return "AeroHUB is not installed. Get it from the store first.";
            case NotRunning:   return "Start the AeroHUB server (or tap Restart server if it is outdated)";
            case NoPermission: return "Tap Allow to give Aero Store AeroHUB access";
            case Blocked:      return "Blocked: switch Aero Store on in AeroHUB > Apps";
            case Outdated:     return "AeroHUB is outdated: tap Restart server in AeroHUB";
            default:           return "AeroHUB connected";
        }
    }

    private static void set(State s) {
        if (state != s) {
            state = s;
            main.post(() -> { Runnable r = onChange; if (r != null) r.run(); });
        }
    }

    private static void checkBlocking() {
        Context c = app;
        if (c == null) return;
        if (!installed(c)) { set(State.NotInstalled); return; }
        if (token.isEmpty()) { set(State.NoPermission); return; }
        AeroHub.Status st = AeroHub.status(token);
        if (st.code == -1) set(State.NotRunning);
        else if (st.code == 0) set(State.Blocked);
        else if (st.version < AeroHub.MIN_SERVER_VERSION) set(State.Outdated);
        else set(State.Ready);
    }

    static void recheck() {
        Thread t = new Thread(() -> { try { checkBlocking(); } catch (Throwable ignore) { } });
        t.setDaemon(true);
        t.start();
    }

    /** AeroHUB has no "died" callback, so re-check every ~4 s while the app is on screen. */
    static void startPolling(Context context) {
        app = context.getApplicationContext();
        final int g = ++pollGen;
        recheck();
        Thread t = new Thread(() -> {
            while (pollGen == g) {
                try { Thread.sleep(4000); } catch (InterruptedException ignore) { }
                if (pollGen == g) { try { checkBlocking(); } catch (Throwable ignore) { } }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    static void stopPolling() { pollGen++; }

    /** Shows AeroHUB's Allow/Deny popup. It must be startActivityForResult from an Activity. */
    static void requestPermission(Activity act) {
        try {
            act.startActivityForResult(new Intent(AeroHub.ACTION_REQUEST).setPackage(AeroHub.PKG), REQ);
        } catch (Exception e) {
            set(State.NotInstalled);
        }
    }

    /** Call from Activity.onActivityResult. */
    static void onResult(Context context, int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ) return;
        if (resultCode == Activity.RESULT_OK && data != null) {
            String t = data.getStringExtra("token");
            if (t != null && !t.isEmpty()) { token = t; SecureStore.put(prefs(context), "token", t); }
        }
        recheck();
    }

    static void openAeroHub(Context context) {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage(AeroHub.PKG);
            if (i != null) context.startActivity(i);
        } catch (Throwable ignore) { }
    }

    static void forget(Context context) {
        token = "";
        SecureStore.remove(prefs(context), "token");
        set(State.NoPermission);
    }

    /** Safe shell quoting: 'text' with every ' replaced by '\'' . Always quote file / package names with it. */
    static String sq(String s) { return "'" + s.replace("'", "'\\''") + "'"; }

    /** Runs a shell command as the shell user. Blocking: call from a background thread. */
    static AeroHub.Result run(String cmd) throws Exception {
        if (state != State.Ready) throw new IllegalStateException("AeroHUB is not connected.");
        try {
            return AeroHub.exec(token, cmd);
        } catch (Exception e) {
            recheck();
            throw new IllegalStateException(e instanceof SecurityException
                    ? "AeroHUB blocked Aero Store. Switch it on in AeroHUB > Apps."
                    : "AeroHUB: " + (e.getMessage() != null ? e.getMessage() : "connection failed"));
        }
    }
}
