package com.aero.store;

import android.util.Base64;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Raw client for the AeroHUB server (runs as the adb shell user on 127.0.0.1:27183). */
final class AeroHub {
    static final String PKG = "com.example.mykuzu";
    static final String ACTION_REQUEST = "com.example.mykuzu.action.REQUEST_PERMISSION";
    private static final int PORT = 27183;
    static final int MIN_SERVER_VERSION = 4;

    private AeroHub() { }

    private static String request(String token, String line, int timeoutMs) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress("127.0.0.1", PORT), 2000);
            s.setSoTimeout(timeoutMs);
            s.getOutputStream().write((token + " " + line + "\n").getBytes(StandardCharsets.UTF_8));
            s.getOutputStream().flush();
            String r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8)).readLine();
            if (r == null) throw new IOException("No reply from AeroHUB");
            return r;
        } finally {
            try { s.close(); } catch (Exception ignore) { }
        }
    }

    /** code: -1 server not running, 0 running but this app is not allowed, 1 allowed. */
    static final class Status {
        final int code, version;
        Status(int code, int version) { this.code = code; this.version = version; }
    }

    static Status status(String token) {
        try {
            String r = request(token, "PING", 3000);
            if (r.equals("DENIED")) return new Status(0, 0);
            if (r.startsWith("OK ")) {
                String[] p = r.split(" ");
                int v = 1;
                if (p.length > 2) { try { v = Integer.parseInt(p[2]); } catch (NumberFormatException ignore) { } }
                return new Status(1, v);
            }
            return new Status(-1, 0);
        } catch (Exception e) {
            return new Status(-1, 0);
        }
    }

    static final class Result {
        final int code;
        final String out;
        Result(int code, String out) { this.code = code; this.out = out; }
    }

    /** Runs a shell command as the shell user. Blocking: call from a background thread. */
    static Result exec(String token, String cmd) throws IOException {
        String enc = Base64.encodeToString(cmd.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String r = request(token, "EXEC " + enc, 90_000);
        if (r.equals("DENIED")) throw new SecurityException("AeroHUB denied this app");
        String[] p = r.split(" ", 2);
        try {
            byte[] b = p.length > 1 && !p[1].isEmpty() ? Base64.decode(p[1], Base64.DEFAULT) : new byte[0];
            return new Result(Integer.parseInt(p[0].trim()), new String(b, StandardCharsets.UTF_8));
        } catch (IllegalArgumentException e) {
            throw new IOException("Bad reply from AeroHUB");
        }
    }
}
