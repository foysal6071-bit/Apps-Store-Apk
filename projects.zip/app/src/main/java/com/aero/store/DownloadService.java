package com.aero.store;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.NotificationCompat;

/**
 * Keeps the app alive while it downloads (so a download goes on when the person leaves the app).
 * It only shows a quiet progress notification and stops itself when nothing is downloading.
 */
public class DownloadService extends Service {

    static final String CHANNEL = "downloads";
    static final int NID = 7002;

    final Handler h = new Handler(Looper.getMainLooper());

    final Runnable update = new Runnable() {
        @Override public void run() {
            int n = Downloader.active();
            if (n == 0) {
                stopForeground(Service.STOP_FOREGROUND_REMOVE);
                stopSelf();
                return;
            }
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(NID, build(n));
            h.postDelayed(this, 1000);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW);
            ch.setSound(null, null);
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Notification n = build(Math.max(1, Downloader.active()));
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(NID, n);
        h.removeCallbacks(update);
        h.post(update);
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        h.removeCallbacks(update);
        super.onDestroy();
    }

    Notification build(int n) {
        int pct = Downloader.overallPct();
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 3, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Aero Store")
                .setContentText(n == 1 ? "Downloading 1 app" : "Downloading " + n + " apps")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(pi)
                .setProgress(100, Math.max(pct, 0), pct < 0)
                .build();
    }
}
