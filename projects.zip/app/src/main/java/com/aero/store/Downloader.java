package com.aero.store;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;

import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The store's own downloader. Files are downloaded by the app itself (not by the phone's Download Manager),
 * into the app's private download folder. Finished downloads are remembered across restarts.
 *
 * State per key (the app link): status running | paused | done | failed, plus got / total bytes.
 */
final class Downloader {

    static final class Item {
        final String key;
        final File file;
        volatile String status = "running";
        volatile long got = 0, total = 0;
        volatile boolean cancel = false;
        Thread thread;
        Item(String key, File file) { this.key = key; this.file = file; }
        File part() { return new File(file.getPath() + ".part"); }
    }

    private static final Map<String, Item> items = new LinkedHashMap<>();
    private static SharedPreferences prefs;
    private static File dir;

    private Downloader() { }

    /* ---------- setup ---------- */

    static synchronized void init(Context c) {
        if (prefs != null) return;
        Context app = c.getApplicationContext();
        prefs = app.getSharedPreferences("dl2", Context.MODE_PRIVATE);
        dir = app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir != null && !dir.exists()) dir.mkdirs();
        try {
            JSONObject o = new JSONObject(prefs.getString("done", "{}"));
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                File f = new File(dir, o.optString(k));
                if (!f.isFile()) continue;
                Item i = new Item(k, f);
                i.status = "done";
                i.got = i.total = f.length();
                items.put(k, i);
            }
        } catch (Exception e) { }
    }

    private static void saveDone() {
        JSONObject o = new JSONObject();
        try {
            for (Item i : items.values()) if ("done".equals(i.status)) o.put(i.key, i.file.getName());
        } catch (Exception e) { }
        prefs.edit().putString("done", o.toString()).apply();
    }

    static String safeName(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        if (n.isEmpty()) n = "app";
        if (!n.toLowerCase().endsWith(".apk")) n += ".apk";
        return n;
    }

    /* ---------- control ---------- */

    static synchronized void start(Context c, String key, String url, String name, String ua, String cookie) throws Exception {
        init(c);
        if (dir == null) throw new IOException("No storage");
        Item old = items.remove(key);
        if (old != null) cancelItem(old);
        File f = new File(dir, safeName(name));
        // another app link may already use this file name: only the newest keeps it
        List<String> same = new ArrayList<>();
        for (Item i : items.values()) if (i.file.equals(f)) same.add(i.key);
        for (String k : same) { Item i = items.remove(k); if (i != null) cancelItem(i); }
        if (f.exists()) f.delete();
        final Item it = new Item(key, f);
        it.part().delete(); // a fresh start never resumes an old half file
        items.put(key, it);
        saveDone();
        it.thread = new Thread(() -> run(it, url, ua, cookie), "dl-" + f.getName());
        it.thread.start();
        try {
            ContextCompat.startForegroundService(c.getApplicationContext(),
                    new Intent(c.getApplicationContext(), DownloadService.class));
        } catch (Throwable t) { /* downloads still run while the app is open */ }
    }

    static synchronized void remove(String key) {
        Item i = items.remove(key);
        if (i != null) cancelItem(i);
        if (prefs != null) saveDone();
    }

    private static void cancelItem(Item i) {
        i.cancel = true;
        if (i.thread != null) i.thread.interrupt();
        i.part().delete();
        i.file.delete();
    }

    /* ---------- reading state ---------- */

    static synchronized JSONObject state() {
        JSONObject out = new JSONObject();
        for (Item i : items.values()) {
            try {
                JSONObject o = new JSONObject();
                o.put("status", i.status);
                o.put("pct", i.total > 0 ? (int) Math.min(100, i.got * 100 / i.total) : 0);
                o.put("got", i.got);
                o.put("total", i.total);
                out.put(i.key, o);
            } catch (Exception e) { }
        }
        return out;
    }

    /* file:// uri of a finished download, else null */
    static synchronized String localUri(String key) {
        Item i = items.get(key);
        if (i == null || !"done".equals(i.status) || !i.file.isFile()) return null;
        return Uri.fromFile(i.file).toString();
    }

    static synchronized int active() {
        int n = 0;
        for (Item i : items.values()) if ("running".equals(i.status) || "paused".equals(i.status)) n++;
        return n;
    }

    /* overall percent of the running downloads, -1 if the sizes are not known */
    static synchronized int overallPct() {
        long got = 0, tot = 0;
        for (Item i : items.values()) {
            if (!"running".equals(i.status) && !"paused".equals(i.status)) continue;
            if (i.total <= 0) return -1;
            got += i.got;
            tot += i.total;
        }
        return tot > 0 ? (int) Math.min(100, got * 100 / tot) : -1;
    }

    /* ---------- the download itself ---------- */

    private static void run(Item it, String url, String ua, String cookie) {
        File part = it.part();
        int attempts = 0;
        while (!it.cancel) {
            HttpURLConnection c = null;
            try {
                long have = part.exists() ? part.length() : 0;
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setInstanceFollowRedirects(true);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                int code = c.getResponseCode();
                boolean append;
                long len = c.getContentLengthLong();
                if (code == 206) {
                    append = true;
                    it.got = have;
                    it.total = len > 0 ? have + len : 0;
                } else if (code == 200) {
                    append = false;
                    it.got = 0;
                    it.total = len > 0 ? len : 0;
                } else {
                    if (code == 416) part.delete(); // cannot resume: start over on the next try
                    throw new IOException("HTTP " + code);
                }
                it.status = "running";
                try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(part, append)) {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while (!it.cancel && (n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        it.got += n;
                    }
                }
                if (it.cancel) return;
                if (it.total > 0 && it.got < it.total) throw new IOException("incomplete");
                if (it.file.exists()) it.file.delete();
                if (!part.renameTo(it.file)) throw new IOException("could not save the file");
                it.total = it.got;
                synchronized (Downloader.class) {
                    it.status = "done";
                    saveDone();
                }
                return;
            } catch (Throwable e) {
                if (it.cancel) return;
                if (++attempts >= 4) {
                    part.delete();
                    it.status = "failed";
                    return;
                }
                it.status = "paused"; // "Waiting for network..."; the next try continues from the bytes already saved
                try { Thread.sleep(3000L * attempts); } catch (InterruptedException ie) { return; }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }
}
