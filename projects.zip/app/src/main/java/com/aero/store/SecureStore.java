package com.aero.store;

import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Stores secrets encrypted with a key that lives in the Android Keystore and never leaves it. */
final class SecureStore {
    private static final String ALIAS = "app_secrets";
    private static final String SUFFIX = "_enc";

    private SecureStore() { }

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        java.security.Key k = ks.getKey(ALIAS, null);
        if (k instanceof SecretKey) return (SecretKey) k;
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return gen.generateKey();
    }

    private static String encrypt(String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        byte[] all = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, all, 0, iv.length);
        System.arraycopy(ct, 0, all, iv.length, ct.length);
        return Base64.encodeToString(all, Base64.NO_WRAP);
    }

    private static String decrypt(String blob) throws Exception {
        byte[] raw = Base64.decode(blob, Base64.NO_WRAP);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, raw, 0, 12));
        return new String(c.doFinal(raw, 12, raw.length - 12), StandardCharsets.UTF_8);
    }

    static String get(SharedPreferences prefs, String name) {
        String enc = prefs.getString(name + SUFFIX, null);
        if (enc == null) return "";
        try { return decrypt(enc); } catch (Throwable t) { return ""; }
    }

    static void put(SharedPreferences prefs, String name, String value) {
        try { prefs.edit().putString(name + SUFFIX, encrypt(value)).apply(); } catch (Throwable ignore) { }
    }

    static void remove(SharedPreferences prefs, String name) {
        prefs.edit().remove(name + SUFFIX).apply();
    }
}
